﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using PlayFab;
using PlayFab.ClientModels;
using ExitGames.Client.Photon;
using System;
using PlayFab.CloudScriptModels;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;

public class PlayFabManager : MonoBehaviour
{
    [Header("Playfab Settings")]
    public string PlayFabUserId;
    public string PlayFabTitleId;
    public static PlayFabManager Instance;
    [SerializeField]
    private bool NoFacebookLogging = false;
    [Header("Playfab Player Keys")]
    public string PlayerDataKey = "PlayerData";
    [Header("Playfab Player Data")]
    public string username;
    public string avatarUrl;
    [SerializeField]
    private int Lives;
    [SerializeField]
    private int Energies;
    [SerializeField]
    private int Darts;

    [SerializeField]
    private int Coins;
    [SerializeField]
    private int Hints;
    [SerializeField]
    private int Timers;
    [SerializeField]
    int Stars;
    [SerializeField]
    private int SpinWheels;
    [SerializeField]
    private int BonusLife1;
    [SerializeField]
    private int BonusLife2;
    [SerializeField]
    private int BonusLife3;
    public BonusLifeTimer bonusLifeTimer;
    public VipTimer vipTimer;
    public string timeToDisplay;

    [Header("Country Data")]
    public CountryClass PlayerCountry = new CountryClass();
    public List<CountryClass> AvailableCountries = new List<CountryClass>();

    TimeSpan timeDifference;
    TimeSpan secondDiff = new TimeSpan(0, 0, 1);
    [Header("Life Caps")]

    private string password;
    [Header("Playfab Player Group Specific Data")]
    public Key currentMember;
    private bool first_login = false;
    [Header("Photon Chat App Id")]
    public string PhotonAppId;
    private string chatToken;


    public Sprite PlayerAvatar;
    #region Getter_Setter 

    public string getAvatar()
    {
        return this.avatarUrl;

    }
    public void setAvatar(string url)
    {
        this.avatarUrl = url;
    }

    public int getLives()
    {
        return this.Lives;
    }
    public void setLives(int lives)
    {
        this.Lives = lives;

    }

    public int getEnergies()
    {
        return this.Energies;
    }
    public void setEnergies(int energies)
    {
        this.Energies = energies;

    }

    public int getDarts()
    {
        return this.Darts;
    }
    public void setDarts(int darts)
    {
        this.Darts = darts;

    }
    public int getCoins()
    {
        return this.Coins;

    }
    public void setCoins(int coins)
    {
        this.Coins = coins;


    }
    public int getSpinWheels()
    {
        return this.SpinWheels;

    }
    public void setSpinWheels(int sw)
    {
        this.SpinWheels = sw;


    }
    public int getTimer()
    {
        return this.Timers;

    }
    public void setTimer(int tms)
    {
        this.Timers = tms;


    }
    public int getHint()
    {
        return this.Hints;

    }
    public void setHint(int hts)
    {
        this.Hints = hts;


    }
    public int getBonusLife1()
    {
        return BonusLife1;
    }
    public int getBonusLife2()
    {
        return BonusLife2;
    }
    public int getBonusLife3()
    {
        return BonusLife3;
    }

    public IEnumerator DownloadAvatar()
    {


        if (Uri.IsWellFormedUriString(getAvatar(), UriKind.Absolute))
        {
            WWW www = new WWW(avatarUrl);
            yield return www;
            PlayerAvatar = Sprite.Create(www.texture, new Rect(0, 0, www.texture.width, www.texture.height), new Vector2(0.5f, 0.5f), 32);
            UiController.Instance.DisplayMyFbProfilePic(PlayerAvatar);
            UIBattleLobby.Instance.SetPlayerSprite(PlayerAvatar);
        }
        else
        {
            PlayerAvatar = Sprite.Create(null, new Rect(0, 0, 200, 200), new Vector2(0.5f, 0.5f), 32);  // you win need to add your own functionality here for default avatars
            UiController.Instance.DisplayMyFbProfilePic(PlayerAvatar);
            UIBattleLobby.Instance.SetPlayerSprite(PlayerAvatar);

        }

    }



    [ContextMenu("Update Avatar")]
    public void SetPlayerAvatar(string url)
    {
        Debug.Log("New Avatar Is" + url);

        UpdateAvatarUrlRequest updateAvatarUrlRequest = new UpdateAvatarUrlRequest
        {
            ImageUrl = url

        };
        PlayFabClientAPI.UpdateAvatarUrl(updateAvatarUrlRequest,
            resultCallback => {
                setAvatar(url);
                StartCoroutine(DownloadAvatar());
            },
            errorCallback => {

                Debug.Log(errorCallback.Error);
            }
            );

    }
    public void setCurrency(ClanSystem.VirtualCurrency.CloudResponse.Response response)
    {
        this.Lives = int.Parse(response.LF);
        this.Timers = int.Parse(response.TM);
        this.Hints = int.Parse(response.HT);
        this.SpinWheels = int.Parse(response.SW);
        this.Coins = int.Parse(response.CO);
        this.BonusLife1 = int.Parse(response.B1);
        this.BonusLife2 = int.Parse(response.B2);
        this.BonusLife3 = int.Parse(response.B3);
        this.Energies = int.Parse(response.EN);
        this.Darts = int.Parse(response.DT);
    }
    #endregion
    #region Bonus_Life_Timer_Functionality
    /// <summary>
    /// This is called whenever any of the BonusLife is consumed. I.e. ConsumeB1,2,3 , CheckIfExpired or  ExpireBonusLife call in StoreSystemController.
    /// </summary>
    public void Bonus_Life_timer_init()
    {
        if (!bonusLifeTimer.useBonusLife)
        {
            timeToDisplay = "00:00";
            return;
        }
        DateTime startTime = Convert.ToDateTime(bonusLifeTimer.startTime);
        DateTime endTime = Convert.ToDateTime(bonusLifeTimer.endTime);
        timeDifference = (endTime - startTime);

        InvokeRepeating("BonusLifeTimer", 1, 1);

    }



    public void BonusLifeTimer()
    {
        timeDifference = timeDifference.Subtract(secondDiff);
        timeToDisplay = timeDifference.ToString();

        if (timeDifference.TotalSeconds < 1)
        {
            StoreSystemController.Instance.ExpireBonusLife();
        }

    }
    #endregion
    #region Login Management 
    void Awake()
    {
        Instance = this;

        GF_SaveLoad.LoadProgress();

    }
    void Start()
    {

        SessionManagement();
    }

    public void signOut()
    {
        GF_SaveLoad.DeleteProgress();
        PlayerPrefs.DeleteAll();
        currentMember = new Key();
        ClanSystemController.Instance.ClearData();
        TradeSystemController.Instance.clearData();
        PlayFabUserId = "";
        username = "";
        password = "";
        UiController.Instance.OnSignOut();
        setEnergies(0);
        setLives(0);
        setCoins(0);
        setSpinWheels(0);
        setTimer(0);
        setHint(0);
        InboxSystemController.Instance.SignOut();

    }
    public void SessionManagement()
    {
        PlayFabSettings.TitleId = PlayFabTitleId;

        /*if (!PlayerPrefs.HasKey("Login_Type"))
            return;
*/

        if (!GF_SaveLoad.CheckIfFileExists() && !PlayerPrefs.HasKey("Login_Type"))
        {
            Debug.Log("No Saved Data Exists");
            return;
        }
        switch (PlayerPrefs.GetString("Login_Type"))
        {
            case "Facebook":
                {
                    if (NoFacebookLogging)
                        LoginGuest();
                    else
                    {

                        if (!PlayerPrefs.HasKey("FacebookToken"))
                        {

                            FaceBook_Login();

                        }
                        else
                        {
                            LoginWithFacebook();

                        }


                    }
                }
                break;
            case "Guest":
                {
                    LoginGuest();

                }
                break;
            case "LoginWithPlayfab":
                {


                    Debug.Log("How Many Times Here");
                    this.username = SaveData.Instance.Username;
                    LoginWithPlayFab(this.username, this.password);

                }
                break;

        }


    }

    public void FaceBook_Login()
    {
        FacebookManager.Instance.FBLogin();
    }

    public void LoginWithPlayFab(string username, string password)
    {
        Debug.Log(1);
        PlayerPrefs.SetString("Login_Type", "LoginWithPlayfab");
        if (!(SaveData.Instance.Username.Length < 1) && !(SaveData.Instance.Password.Length < 1) && GF_SaveLoad.CheckIfFileExists())
        {
            username = SaveData.Instance.Username;
            password = SaveData.Instance.Password;
            Debug.Log(2 + " " + SaveData.Instance.Password + "" + SaveData.Instance.Username);

        }
        else
        {
            SaveData.Instance = new SaveData(username, password);
            GF_SaveLoad.SaveProgress();
            Debug.Log(3 + " " + SaveData.Instance.Password + "" + SaveData.Instance.Username);

        }
        this.username = username;
        this.password = password;
        PlayFabSettings.TitleId = PlayFabTitleId;

        LoginWithPlayFabRequest request = new LoginWithPlayFabRequest
        {
            Password = password,
            TitleId = PlayFabTitleId,
            Username = username,
        };


        PlayFabClientAPI.LoginWithPlayFab(request, OnLoginSuccess, OnLoginFail);
    }
    public void LoginWithDevice()
    {
        Debug.Log("am i coming here twice");
        if (!PlayerPrefs.HasKey("Login_Type"))
        {
            LoginGuest();
        }
        else
        {
            Debug.Log(PlayerPrefs.GetString("Login_Type"));
            switch (PlayerPrefs.GetString("Login_Type"))
            {
                case "Facebook":
                    {
                        if (NoFacebookLogging)
                            LoginGuest();
                        else
                            FacebookManager.Instance.FBLogin();
                    }
                    break;
                case "Guest":
                    {
                        LoginGuest();

                    }
                    break;
                case "LoginWithPlayfab":
                    {

                    }
                    break;
            }


        }

    }
    public void LoginGuest()
    {
        Debug.Log("Title id is : " + PlayFabSettings.TitleId);
        PlayerPrefs.GetString("Login_Type", "Guest");



#if UNITY_ANDROID || ANDROID
        LoginWithAndroidDeviceIDRequest request = new LoginWithAndroidDeviceIDRequest
        {
            AndroidDevice = SystemInfo.deviceModel,
            AndroidDeviceId = ReturnDeviceId(),
            TitleId = PlayFabSettings.TitleId,
            OS = SystemInfo.operatingSystem,
            CreateAccount = true
        };
        PlayFabClientAPI.LoginWithAndroidDeviceID(request, DeviceLoginSuccess,


                (CustomIdLoginError) =>
                {
                    Debug.Log("Error logging in player with custom ID: ");
                    Debug.Log(CustomIdLoginError.ErrorMessage);
                }


              );

#endif



#if UNITY_IOS || IOS

        //IOS will be here

        LoginWithIOSDeviceIDRequest iosrequest = new LoginWithIOSDeviceIDRequest { TitleId = PlayFabSettings.TitleId, DeviceId = ReturnDeviceId(), CreateAccount = true, OS = SystemInfo.operatingSystem };
        PlayFabClientAPI.LoginWithIOSDeviceID(  iosrequest,DeviceLoginSuccess,
              (CustomIdLoginError) =>
              {
                  Debug.Log("Error logging in player with custom ID: ");
                  Debug.Log(CustomIdLoginError.ErrorMessage);
              }
   );



#endif
    }
    public string ReturnDeviceId()
    {
        return SystemInfo.deviceUniqueIdentifier;
    }
    public void DeviceLoginSuccess(LoginResult deviceLoginResult)
    {



        // this is where you can tell the ui to prompt user to set username as this callback is called is called in case of android login



        PlayFabUserId = deviceLoginResult.PlayFabId;
        if (deviceLoginResult.NewlyCreated)
        {
            PlayerPrefs.SetString("Login_Type", "Guest");
            sendDataOnAccountRegisteration();
            UiController.Instance.showSetUserNamePanelForAndroidUser();
            SetPlayerAvatar((1).ToString());
            return;



        }
        else
        {
            PlayerPrefs.SetString("Login_Type", "Guest");
            getDataOnAccountLogin();
        }
        ClanSystemController.Instance.GetCurrentPlayerDataForGroup(PlayFabUserId);
        Debug.Log("i show result here " + deviceLoginResult);
        UiController.Instance.OpenGroupOptions();
        //   TournamentSystem.Instace.GetTeamTournamentForPlayer();
        RequestCurrency();
        GetSpinWheelItems();
        StoreSystemController.Instance.getIAPItems();
        StoreSystemController.Instance.CheckIfBonusLifeExpired();
        StoreSystemController.Instance.getVipTime();


        StoreSystemController.Instance.RegisterUserLoginTimeStamp();
        EventControllerScript.Instance.GetTodayEventDetails();
        TournamentSystem.Instace.getPersonalTournament();
        EnergySystem.Instance.GetLevels();
        EnergySystem.Instance.ResumeTimer();
        InboxSystemController.Instance.OnSignin();
        ClanSystemController.Instance.ListMembershipRequestForCurrentMember();
        GetPlayerCountry();
        StartCoroutine(FakePlayerHandler.Instance.GetLeaderboard());

    }



    public void GetPlayerCountry()
    {



        PlayFabCloudScriptAPI.ExecuteEntityCloudScript(new ExecuteEntityCloudScriptRequest
        {
            FunctionName = "GetPlayerCountry",
        }, resultCallback => {
            try
            {
                Debug.Log(resultCallback.FunctionResult.ToString());
                PlayerCountry = AvailableCountries.Find((ob) =>
                ob.CountryCode == resultCallback.FunctionResult.ToString());


            }
            catch
            {
                Debug.Log("Unexpected Output");

            }

        }
        , errorCallback => {

            Debug.LogError(errorCallback.ErrorMessage);
        }


        );
    }
    public void SetUserNameOnPlayFab(string userName)
    {

        UpdateUserTitleDisplayNameRequest request = new UpdateUserTitleDisplayNameRequest
        {


            DisplayName = userName

        };

        PlayFabClientAPI.UpdateUserTitleDisplayName(request,

            resultCallback => {

                Debug.Log("Successfully Changed");


            }, errorCallback => {



                UiController.Instance.showError(errorCallback.ErrorMessage);
            }

            );



    }
    public void SetUserNameOnPlayFab()
    {

        UpdateUserTitleDisplayNameRequest request = new UpdateUserTitleDisplayNameRequest
        {


            DisplayName = username

        };

        PlayFabClientAPI.UpdateUserTitleDisplayName(request,

            resultCallback => {

                if (PlayerPrefs.GetString("Login_Type") == "Guest")
                {
                    ClanSystemController.Instance.GetCurrentPlayerDataForGroup(PlayFabUserId);
                    Debug.Log("i show result here " + resultCallback);
                    UiController.Instance.OpenGroupOptions();
                    RequestCurrency();
                    GetSpinWheelItems();
                    //  TournamentSystem.Instace.GetTeamTournamentForPlayer();
                    StoreSystemController.Instance.getIAPItems();
                    StoreSystemController.Instance.CheckIfBonusLifeExpired();
                    StoreSystemController.Instance.getVipTime();
                    StoreSystemController.Instance.RegisterUserLoginTimeStamp();
                    EventControllerScript.Instance.GetTodayEventDetails();
                    UiController.Instance.TurnOffSetUserNamePanelForAndroidUser();
                    TournamentSystem.Instace.getPersonalTournament();
                    EnergySystem.Instance.GetLevels();
                    EnergySystem.Instance.ResumeTimer();
                    InboxSystemController.Instance.OnSignin();
                    ClanSystemController.Instance.ListMembershipRequestForCurrentMember();
                    GetPlayerCountry();
                    StartCoroutine(FakePlayerHandler.Instance.GetLeaderboard());

                }


            }, errorCallback => {



                UiController.Instance.showError(errorCallback.ErrorMessage);
            }

            );



    }
    private void OnLoginSuccess(LoginResult result)
    {

        // AndroidIAPExample.Instance.RefreshIAPItems();



        PlayFabUserId = result.PlayFabId;
        if (first_login)
        {
            sendDataOnAccountRegisteration();
            //  SetPlayerAvatar();
            first_login = false;
            //SetUserNameOnPlayFab(); // have commented this out for setting display name only on joining group functionality 
            if (PlayerPrefs.GetString("Login_Type") == "Facebook")
            {
                SetUserNameOnPlayFab();
            }
            else
            {
                SetPlayerAvatar((2).ToString());
            }
        }
        else
        {
            getDataOnAccountLogin();
        }
        //GetAccountInfo();
        Debug.Log("i show result here " + result);

        OnLoginCalls();

    }


    [ContextMenu("Enable Chat")]
    public void EnableChat()
    {
        currentMember.MemberPersonalData.ChatEnabled = true;
        UpdateUserReadOnlyData(JsonUtility.ToJson(currentMember.MemberPersonalData));
        ChatManager.Instance.OnChatEnabled();
    }
    [ContextMenu("Disable Chat")]
    public void DisableChat()
    {

        currentMember.MemberPersonalData.ChatEnabled = false;
        UpdateUserReadOnlyData(JsonUtility.ToJson(currentMember.MemberPersonalData));
        ChatManager.Instance.OnChatDisabled();
    }
    [ContextMenu("Win Round")]
    public void WinRound()
    {


        PlayFabCloudScriptAPI.ExecuteEntityCloudScript(new ExecuteEntityCloudScriptRequest
        {
            FunctionName = "WinRound",
        }, resultCallback => {
            try
            {
                Debug.Log("working");
                Debug.Log(resultCallback.FunctionResult.ToString());
                currentMember.MemberPersonalData = JsonUtility.FromJson<MemberData>(resultCallback.FunctionResult.ToString());
                EnergySystem.Instance.setplayerLevel(currentMember.MemberPersonalData.Level);
                UiController.Instance.UpdateLevelSystemUI(currentMember.MemberPersonalData.Level.ToString(), currentMember.MemberPersonalData.Experience, currentMember.MemberPersonalData.RequiredExperience);
            }
            catch
            {
                Debug.Log("Unexpected Output");

            }

        }
        , errorCallback => {

            Debug.LogError(errorCallback.ErrorMessage);
        }


        );



    }
    [ContextMenu("IncreaseStars")]
    public void IncreaseStars(int starsToAdd = 1)
    {






        PlayFabCloudScriptAPI.ExecuteEntityCloudScript(new ExecuteEntityCloudScriptRequest
        {
            FunctionName = "IncreaseStars",
            FunctionParameter = new
            {
                StarsToAdd = starsToAdd

            }








        }, resultCallback => {
            try
            {
                Debug.Log("working");
                Debug.Log(resultCallback.FunctionResult.ToString());
                currentMember.MemberPersonalData = JsonUtility.FromJson<MemberData>(resultCallback.FunctionResult.ToString());
                /*    EnergySystem.Instance.setplayerLevel(currentMember.MemberPersonalData.Level);
                    UiController.Instance.UpdateLevelSystemUI(currentMember.MemberPersonalData.Level.ToString(), currentMember.MemberPersonalData.Experience, currentMember.MemberPersonalData.RequiredExperience);
                */
            }
            catch
            {
                Debug.Log("Unexpected Output");

            }

        }
        , errorCallback => {

            Debug.LogError(errorCallback.ErrorMessage);
        }


        );



    }





    public void setUsername(string uname)
    {
        Debug.Log("before" + this.username);
        this.username = uname;
        Debug.Log("after" + this.username);
    }

    public void SendPlayerData()
    {
        UpdateUserReadOnlyData(JsonUtility.ToJson(currentMember.MemberPersonalData));
    }



    private void successfulUpdate(UpdateUserDataResult result)
    {

        Debug.Log(result);
    }
    private void failUpdate(PlayFabError error)
    {
        Debug.Log(error);
    }

    private void OnLoginFail(PlayFabError error)
    {



        Debug.Log("i show result here " + error.Error);
        PlayerPrefs.DeleteAll();
        switch (error.Error.ToString())
        {
            case "AccountNotFound":
                {
                    RegisterAccount();
                }
                break;
            default:
                {
                    signOut();
                }
                break;
        }
    }

    public void RegisterAccount()
    {
        RegisterPlayFabUserRequest request = new RegisterPlayFabUserRequest
        {
            Username = this.username,
            RequireBothUsernameAndEmail = false,
            Password = this.password,
            TitleId = PlayFabTitleId
        };


        PlayFabClientAPI.RegisterPlayFabUser(request, (RegisterPlayFabUserResult) =>
        {

            first_login = true;


            LoginWithPlayFab(this.username, this.password);

        }, OnLoginFail);
    }


    //
    ////
    /// <summary>
    ///this run on account registeration for both device and username/password login . no username will be send in device's case and "guest" username will be user
    ///also this is only for player title data not actual username
    /// </summary>
    /// <param name="DummyUserName"></param>
    public void sendDataOnAccountRegisteration()
    {
        GetAccountInfoRequest request = new GetAccountInfoRequest()
        {
            PlayFabId = PlayFabUserId

        };
        PlayFabClientAPI.GetAccountInfo(request, result =>
        {
            currentMember = new Key(result.AccountInfo.TitleInfo.TitlePlayerAccount.Id,
            result.AccountInfo.TitleInfo.TitlePlayerAccount.Id, 1, 0, 64, 0);
            UpdateUserReadOnlyData(JsonUtility.ToJson(currentMember.MemberPersonalData));



        }, failUpdate);
    }

    public int getStars()
    {

        return this.Stars;

    }
    public void setStars(int strs)
    {
        this.Stars = strs;

    }

    public void UpdateUserReadOnlyData(string playerData)
    {



        PlayFabCloudScriptAPI.ExecuteEntityCloudScript(new ExecuteEntityCloudScriptRequest
        {
            FunctionName = "UpdateUserReadOnlyData",
            FunctionParameter = new
            {
                PlayerData = playerData
            }


        }, CloudScriptSuccess


        , CloudScriptFailure


        );









    }

    public void GetUserReadOnlyData()
    {



        PlayFabCloudScriptAPI.ExecuteEntityCloudScript(new ExecuteEntityCloudScriptRequest
        {
            FunctionName = "GetUserReadOnlyData"

        }, resultCallback => {

            Debug.Log(resultCallback.FunctionName);
            Debug.Log(resultCallback.FunctionResult);

            GetAccountInfo();


            currentMember.MemberPersonalData = JsonUtility.FromJson<MemberData>(resultCallback.FunctionResult.ToString());
            if (!resultCallback.FunctionResult.ToString().Contains("ChatEnabled"))
            {

                currentMember.setChatEnabled(true);


            }


            EnergySystem.Instance.setplayerLevel(currentMember.MemberPersonalData.Level);
            UiController.Instance.UpdateLevelSystemUI(currentMember.MemberPersonalData.Level.ToString(),
            currentMember.MemberPersonalData.Experience, currentMember.MemberPersonalData.RequiredExperience);


        }


        , CloudScriptFailure


        );









    }

    public void CloudScriptSuccess(PlayFab.CloudScriptModels.ExecuteCloudScriptResult result)
    {


        Debug.Log(result.FunctionResult);
        Debug.Log(result.FunctionName);
        switch (result.FunctionName)
        {

            case "GetUserReadOnlyData":
                {

                    UiController.Instance.UpdateLevelSystemUI(currentMember.MemberPersonalData.Level.ToString(),
                        currentMember.MemberPersonalData.Experience, currentMember.MemberPersonalData.RequiredExperience);



                }
                break;

            case "UpdateUserReadOnlyData":
                {

                    UiController.Instance.UpdateLevelSystemUI(currentMember.MemberPersonalData.Level.ToString(),
                        currentMember.MemberPersonalData.Experience, currentMember.MemberPersonalData.RequiredExperience);



                }
                break;


        }


    }

    public void CloudScriptFailure(PlayFabError error)
    {


    }

    public void getDataOnAccountLogin()
    {
        Debug.Log("am i coming here on both cases");
        GetUserReadOnlyData();
    }
    public string EncodeImageToBase64(Texture2D tex)
    {
        /*byte[] bytes;
        using (MemoryStream ms = new MemoryStream())
        {
            BinaryFormatter bf = new BinaryFormatter();
            bf.Serialize(ms, tex);
            bytes = ms.ToArray();
        }*/

        byte[] bytes;
        bytes = tex.EncodeToPNG();
        string enc = Convert.ToBase64String(bytes);
        return enc;
    }

    public IEnumerator UploadPlayerProfilePictureAsAvatar(string tex)
    {
        Debug.Log("Coming here to updated Avatar 1");

        while (!PlayFabClientAPI.IsClientLoggedIn())
        {
            yield return new WaitForSeconds(.25f);
        }

        Debug.Log("Coming here to updated Avatar 2");
        SetPlayerAvatar(tex);
        //SetPlayerAvatar(EncodeImageToBase64(tex));



    }
    public void GetAccountInfo() // fixed current member id issue 
    {
        GetAccountInfoRequest request = new GetAccountInfoRequest()
        {
            PlayFabId = PlayFabUserId
        };
        PlayFabClientAPI.GetAccountInfo(request, result =>
        {
            currentMember.setTitleId(result.AccountInfo.TitleInfo.TitlePlayerAccount.Id);
            if (result.AccountInfo.TitleInfo.DisplayName != null)
            {
                setUsername(result.AccountInfo.TitleInfo.DisplayName);
                currentMember.setGroupUsername(result.AccountInfo.TitleInfo.DisplayName);
            }
            if (result.AccountInfo.TitleInfo.AvatarUrl != null)
            {
                setAvatar(result.AccountInfo.TitleInfo.AvatarUrl);
                StartCoroutine(DownloadAvatar());
                //  UiController.Instance.DisplayMyFbProfilePic();
            }
            else
            {
                SetPlayerAvatar((2).ToString());

            }
            if (result.AccountInfo.TitleInfo.DisplayName == null)
            {
                if (PlayerPrefs.GetString("Login_Type") == "Facebook")
                {

                    SetUserNameOnPlayFab();

                }





            }
        }, failUpdate);


    }
    private void OnDataReceived(GetUserDataResult dataResult)
    {
        if (dataResult.Data.ContainsKey(PlayerDataKey))
        {
            GetAccountInfo();
            currentMember.MemberPersonalData = JsonUtility.FromJson<MemberData>(dataResult.Data[PlayerDataKey].Value);
            EnergySystem.Instance.setplayerLevel(currentMember.MemberPersonalData.Level);

        }
    }
    [Header("Panel Where User Can Enter GroupUsername If It Does Not Exist")]
    public GameObject EnterUserNamePanel;
    public void ToOpenEnterGroupUserNameOrNot()
    {


        Debug.Log("Group Name Exists Or Not" + CheckIfGroupUserNameAlreadyExists());

        if (CheckIfGroupUserNameAlreadyExists())
        {
            EnterUserNamePanel.SetActive(false);
            ClanSystemController.Instance.ApplyToGroup();
        }
        else
        {
            EnterUserNamePanel.SetActive(true);


        }

    }

    public bool CheckIfGroupUserNameAlreadyExists()
    {
        //Group Name
        Debug.Log("Group Username is :" + currentMember.GetGroupUsername());
        return !(currentMember.GetGroupUsername() == "");

    }
    private void OnDataNotReceived(PlayFabError error)
    {

        Debug.Log(error);
    }

    public void LoginWithFacebook()
    {


        if (!PlayerPrefs.HasKey("FacebookId"))
        {
            FaceBook_Login();
            return;
        }


        /* else 
         {
             FacebookManager.Instance.getMyProfilePicture(PlayerPrefs.GetString("FacebookId"));

         }*/
        LoginWithFacebookRequest FBLoginRequest = new LoginWithFacebookRequest()
        {
            TitleId = PlayFabTitleId,
            CreateAccount = true,
            AccessToken = PlayerPrefs.GetString("FacebookToken")
        };

        PlayFabClientAPI.LoginWithFacebook(FBLoginRequest, (FBLoginResult) =>
        {
            if (FBLoginResult.NewlyCreated)
            {
                first_login = true;
                PlayerPrefs.SetString("Login_Type", "Facebook");
                LinkFacebookAccountRequest FaceBookLinkRequest = new LinkFacebookAccountRequest()
                { AccessToken = Facebook.Unity.AccessToken.CurrentAccessToken.TokenString, ForceLink = true };

                PlayFabClientAPI.LinkFacebookAccount(FaceBookLinkRequest, result =>
                {
                    OnLoginSuccess(FBLoginResult);

                }, FailedlLinking);

                /* SetUserNameOnPlayFab(this.username);*/



            }
            else
            {
                OnLoginSuccess(FBLoginResult);
            }
        }, (FBLoginError) =>
        {
            Debug.Log("Error logging in player with facebook ID: " + FBLoginError.ErrorMessage + "\n" + FBLoginError.ErrorDetails);
            Debug.Log(FBLoginError.Error);
            switch (FBLoginError.Error)
            {

                case PlayFabErrorCode.AccountNotFound:
                    {
                        PlayerPrefs.SetString("Login_Type", "Facebook");
                        LinkFacebookAccountRequest FaceBookLinkRequest = new LinkFacebookAccountRequest()
                        { AccessToken = Facebook.Unity.AccessToken.CurrentAccessToken.TokenString, ForceLink = true };
                        PlayFabClientAPI.LinkFacebookAccount(FaceBookLinkRequest, SuccessfulLinking, FailedlLinking);



                    }
                    break;
                case PlayFabErrorCode.FacebookAPIError:
                    {

                        FaceBook_Login();


                    }
                    break;
            }
        });
    }
    public void FailedlLinking(PlayFabError error)
    {
        Debug.Log(error);
    }
    public void SuccessfulLinking(LinkFacebookAccountResult result)
    {
        first_login = true;
        Debug.Log(result);
    }

    #endregion
    #region Photon_Setup
    public void GetPhotonDetails()
    {

        Debug.Log("COMING HERE TOO");
        GetPhotonAuthenticationTokenRequest request = new GetPhotonAuthenticationTokenRequest()
        {
            PhotonApplicationId = PhotonAppId

        };

        PlayFabClientAPI.GetPhotonAuthenticationToken(request,
            resultCallback =>
            {
                chatToken = resultCallback.PhotonCustomAuthenticationToken;
                Debug.Log("Starting Chat " + chatToken);
                ChatManager.Instance.AuthenticateWithPlayfab(chatToken);

            }, error =>
            {
                Debug.Log(error.Error);
            }

            );
    }
    #endregion
    #region Function_calls_Controllers
    public void GetLifeRequests()
    {
        //    TradeSystemController.Instance.GetEnergyRequests(currentMember.MemberGroup.Id);
        TradeSystemController.Instance.GetLifeRequests(currentMember.MemberGroup.Id);

        TradeSystemController.Instance.GetUserLifeMessages();
    }
    public void RequestCurrency()
    {
        TradeSystemController.Instance.LoadVirtualCurrency();
    }
    public void GetSpinWheelItems()
    {

        SpinWheelController.Instance.LoadSpinWheelTable();

    }
    [ContextMenu("DeductEnergy")]
    public void DeductEnergy()
    {
        EnergySystem.Instance.deductEnergy();

    }
    #endregion


    public void OnLoginCalls()
    {


        //  TournamentSystem.Instace.GetTeamTournamentForPlayer();
        ClanSystemController.Instance.GetCurrentPlayerDataForGroup(PlayFabUserId);
        UiController.Instance.OpenGroupOptions();
        RequestCurrency();
        GetSpinWheelItems();
        StoreSystemController.Instance.getIAPItems();
        StoreSystemController.Instance.CheckIfBonusLifeExpired();
        StoreSystemController.Instance.getVipTime();
        StoreSystemController.Instance.RegisterUserLoginTimeStamp();
        EventControllerScript.Instance.GetTodayEventDetails();
        TournamentSystem.Instace.getPersonalTournament();
        EnergySystem.Instance.GetLevels();
        EnergySystem.Instance.ResumeTimer();
        InboxSystemController.Instance.OnSignin();
        ClanSystemController.Instance.ListMembershipRequestForCurrentMember();
        GetPlayerCountry();
        StartCoroutine(FakePlayerHandler.Instance.GetLeaderboard());


    }
}
