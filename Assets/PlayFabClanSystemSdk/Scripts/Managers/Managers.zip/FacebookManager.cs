﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Facebook.Unity;
using Facebook.MiniJSON;
using PlayFab;
using PlayFab.ClientModels;

public class FacebookManager : MonoBehaviour
{


	public static FacebookManager Instance;
	[HideInInspector] public string MyUniqueFbId = null;
	[HideInInspector] public string MyFbName = null;
	[HideInInspector] public string MyFbAvatarUrl = null;
	[HideInInspector] public bool IsloggedIn = false;
	[HideInInspector] public Sprite MyFbAvatar = null;

	void Awake()
	{

		if (Instance != null)
		{
			Destroy(this.gameObject, 0.2f);

			return;

		}
		Instance = this;
		DontDestroyOnLoad(this);


		if (string.IsNullOrEmpty(PlayFabSettings.TitleId))
		{
			/*
            Please change the titleId below to your own titleId from PlayFab Game Manager.
            If you have already set the value in the Editor Extensions, this can be skipped.
            */
			PlayFabSettings.TitleId = "EF20A";
		}

		if (!FB.IsInitialized)
		{
			FB.Init(InitializationCallBack, OnHideUnity);
		}
		else
		{
			FB.ActivateApp();
		}


	}
	void MakeSingleton()
	{
		if (Instance == null)
		{
			Instance = this;
		}


	}

	void InitializationCallBack()
	{
		if (FB.IsInitialized)
		{
			FB.ActivateApp();
			//	InitializeSession ();
		}
		else
		{
			Debug.Log("Facebook Initialization Failed");
		}
	}

	void OnHideUnity(bool isGameShown)
	{
		if (!isGameShown)
		{
			Time.timeScale = 0;
		}
		else
		{
			Time.timeScale = 2;
		}
	}

	void InitializeSession()
	{
		string LoginType = PlayerPrefs.GetString("Login_Type");

		if (LoginType.Equals("Facebook"))
		{
			MyUniqueFbId = Facebook.Unity.AccessToken.CurrentAccessToken.UserId;
			IsloggedIn = true;
			GetFacebookUserName();
			GetFacebookProfilePic(MyUniqueFbId);
			Debug.Log(MyUniqueFbId + " Is fb user ID");
			//	Debug.Log(MyUniqueFbId);
		}
	}




	public void getMyProfilePicture(string userID)
	{
		FB.API("/me?fields=picture.width(200).height(200)", Facebook.Unity.HttpMethod.GET, delegate (IGraphResult result)
		{
			if (result.Error == null)
			{

				Dictionary<string, object> reqResult = Json.Deserialize(result.RawResult) as Dictionary<string, object>;

				if (reqResult == null) Debug.Log("JEST NULL"); else Debug.Log("nie null");


				MyFbAvatarUrl = ((reqResult["picture"] as Dictionary<string, object>)["data"] as Dictionary<string, object>)["url"] as string;
				Debug.Log("My avatar " + MyFbAvatarUrl);
				StartCoroutine(PlayFabManager.Instance.UploadPlayerProfilePictureAsAvatar(MyFbAvatarUrl));
				StartCoroutine(loadImageMy(MyFbAvatarUrl));


			}
			else
			{
				Debug.Log("Error retreiving image: " + result.Error);
			}
		});


	}

	public IEnumerator loadImageMy(string url)
	{
		WWW www = new WWW(url);
		yield return www;
		UiController.Instance.DisplayMyFbProfilePic(Sprite.Create(www.texture, new Rect(0, 0, www.texture.width, www.texture.height), new Vector2(0.5f, 0.5f), 32));
	}











	void GetFacebookUserName()
	{
		FB.API("me?fields=first_name,last_name", Facebook.Unity.HttpMethod.GET, FbUserNameCallBack);

	}

	void FbUserNameCallBack(IResult ServerResponse)
	{
		MyFbName = ServerResponse.ResultDictionary["first_name"].ToString() + " " + ServerResponse.ResultDictionary["last_name"].ToString();
		PlayFabManager.Instance.setUsername(MyFbName);
		Debug.Log("Facebook name " + MyFbName);
	}

	void GetFacebookProfilePic(string FbUserId)
	{
		StartCoroutine(DownloadPlayerAvatar("nope"));

	}



	public void LogoutFromFacebook()
	{
		StartCoroutine(FBLogout());



	}

	IEnumerator FBLogout()
	{


		FB.LogOut();
		while (FB.IsLoggedIn)
		{
			print("Logging Out");

			yield return null;
		}
		print("Logout Successful");
		IsloggedIn = false;

	}


	IEnumerator DownloadPlayerAvatar(string AvatarURL)
	{
		yield return null;
		PlayerPrefs.SetString("FacebookToken", Facebook.Unity.AccessToken.CurrentAccessToken.TokenString);
		PlayerPrefs.SetString("FacebookId", Facebook.Unity.AccessToken.CurrentAccessToken.UserId);
		getMyProfilePicture(Facebook.Unity.AccessToken.CurrentAccessToken.UserId);
		PlayFabManager.Instance.LoginWithFacebook();


	}



	public void UserWishesToLink()
	{

		//	SettingScript.Instance.userWishesToLink = true;

	}

	public void FBLogin()
	{
		StartCoroutine(WaitForFacebook());

	}



	public IEnumerator WaitForFacebook()
	{
		yield return new WaitForSeconds(3f);
		if (!IsloggedIn)
		{
			var perms = new List<string>() { "public_profile", "email", "user_friends" };
			FB.LogInWithReadPermissions(perms, LoginResultCallback);
		}
		else
		{
			Debug.Log("Already Logged In");
		}

	}
	private void LoginResultCallback(ILoginResult Result)
	{
		if (FB.IsLoggedIn)
		{
			var aToken = Facebook.Unity.AccessToken.CurrentAccessToken;
			MyUniqueFbId = aToken.UserId;
			foreach (string perm in aToken.Permissions)
			{
				Debug.Log(perm);
			}
			PlayerPrefs.SetString("Login_Type", "Facebook");
			InitializeSession();
		}
		else
		{
			Debug.Log("error cause" + Result.Error);
			Debug.Log("User cancelled login");
		}
	}


	#region LeaderBoard Api

	public void GetFacebookUserName(string id, Action<IGraphResult> successCallback = null, Action<IGraphResult> errorCallback = null)
	{
		FB.API("/" + id, HttpMethod.GET,
			(res =>
			{
				if (!ValidateResult(res))
				{
					if (errorCallback != null)
						errorCallback(res);

					return;
				}

				Debug.Log(string.Format("FacebookManager.GetFacebookUserName => Success! (name: {0})",
					res.ResultDictionary["name"]));

				if (successCallback != null)
					successCallback(res);
			}));
	}

	public void GetFacebookUserPicture(string id, int width, int height, Action<IGraphResult> successCallback = null, Action<IGraphResult> errorCallback = null)
	{
		string query = string.Format("/{0}/picture?type=square&height={1}&width={2}", id, height, width);

		FB.API(query, HttpMethod.GET,
			(res =>
			{
				if (!ValidateResult(res) || res.Texture == null)
				{
					if (errorCallback != null)
						errorCallback(res);

					return;
				}

				if (successCallback != null)
					successCallback(res);

				//Debug.Log("Leaderboard.GetFacebookUserPicture => Success!");
			}));
	}

	private bool ValidateResult(IResult result)
	{
		if (string.IsNullOrEmpty(result.Error) && !result.Cancelled)
			return true;

		//Debug.Log(string.Format("{0} is invalid (Cancelled={1}, Error={2}, JSON={3})",
		//    result.GetType(), result.Cancelled, result.Error, Facebook.MiniJSON.Json.Serialize(result.ResultDictionary)));

		return false;
	}

	#endregion

	public void destroy()
	{
		if (this.gameObject != null)
			DestroyImmediate(this.gameObject);
	}

































}
